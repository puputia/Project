let yaiba = {
    title: "귀멸의 칼날 무한열차편",
    year: 2020,
    nation: "Japan",
    poster: "https://w.namu.la/s/b4ad8ddef40bb8820d025a0d4991ef9fa5edf6f31c8c0c7faeea1460c1a8f6f055f2ad5bb20913f219a704dea055eb57eb023b50908670e965f590953dd672f2850097e7b281b58f2a819b56bb52da82f207d24a027cb5ef82b0777a9623a3a1"
};

let Happy = {
    title: "해피데스데이",
    year: 2017,
    nation: "USA",
    poster: "https://ww.namu.la/s/7de85d97175d75602ff86bfcc1d8965ca0a570315e3f3af94cf1b94f8aab997858ccf9a60bae218c1fa4620f40abf0862815a157bfcef97272fd89722c6b3d6dadbd7ebb6b73741ebf1030ce84debc32c351cc867b058d069f89dc5802d1ec14ffa147a9418705928e19dc0f988a0298"
};

let baby = {
    title: "보스베이비",
    year: 2017,
    nation: "USA",
    poster: "https://ww.namu.la/s/f0506e788302f6d82a84d46c42c12a4d27230458ee75227b20186708e18e165d7525d7b5f940e7f3888a787413f776839da9e75ff68145ccbe0a67a691b6eb59945114c88899cee1249e3c1ea92b2a47fdc56e1e8e9df10950d71ad64dc3c4f3787100203415f03ca6e12a4e1daf93a9"
};

let aboutime = {
    title: "어바웃타임",
    year: 2013,
    nation: "UK",
    poster: "https://w.namu.la/s/b4ad8ddef40bb8820d025a0d4991ef9fa5edf6f31c8c0c7faeea1460c1a8f6f055f2ad5bb20913f219a704dea055eb57eb023b50908670e965f590953dd672f2850097e7b281b58f2a819b56bb52da82f207d24a027cb5ef82b0777a9623a3a1"
};

let title = document.getElementsByClassName("title");
let year = document.getElementsByClassName("year");
let nation = document.getElementsByClassName("nation");
let poster = document.getElementsByClassName("poster");
let info = document.getElementsByClassName("info");


function showMovieInfo(Movie) {
	title[0].innerHTML = Movie.title;
	year[0].innerHTML = Movie.year;
	nation[0].innerHTML = Movie.nation;
    poster[0].innerHTML = Movie.poster;
	info[0].classList.remove("hide");
}
 