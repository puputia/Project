var mist = {
	title: "미스트",
	year: 2007,
	genre: "horror"
};
var identity = {
	title: "아이덴티티",
	year: 2003,
	genre: "drama"
};
var shutterIsland = {
	title: "셔터 아일랜드",
	year: 2010,
	genre: "drama"
};

var title = document.getElementsByClassName("title");
var info = document.getElementsByClassName("info");
var year = document.getElementsByClassName("year");
var genre = document.getElementsByClassName("genre");

function showMovieInfo(movieTitle) {
	title[0].innerHTML = movieTitle.title;
	year[0].innerHTML = movieTitle.year;
	genre[0].innerHTML = movieTitle.genre;

	info[0].classList.remove("hide");
}